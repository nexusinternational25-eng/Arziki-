<?php
/**
 * Script de traitement du formulaire de contact pour hébergement LWS mutualisé.
 * 
 * Actions :
 * 1. Validation et sécurisation des champs.
 * 2. Anti-spam simple (honeypot).
 * 3. Envoi réel d’email via mail() PHP.
 * 4. Redirection vers index.html avec message de succès/erreur.
 */

// --- Configuration ---
define('RECIPIENT_TO', 'operation@amanexus.com');
define('RECIPIENT_CC', 'nexusinternational25@gmail.com');
define('HONEYPOT_FIELD', 'website'); // Nom du champ honeypot (doit être vide)
define('REDIRECT_URL', 'index.html');

// Fonction de redirection avec message de statut
function redirect($status, $message = '') {
    $url = REDIRECT_URL . '?status=' . $status;
    if (!empty($message)) {
        $url .= '&message=' . urlencode($message);
    }
    header('Location: ' . $url);
    exit;
}

// Vérifier si la requête est bien une soumission de formulaire POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('error', 'Méthode de requête non autorisée.');
}

// --- 1. Anti-spam Honeypot ---
if (!empty($_POST[HONEYPOT_FIELD])) {
    // Si le champ honeypot est rempli, c'est un bot. On redirige sans erreur.
    redirect('success'); // Simuler le succès pour ne pas alerter le bot
}

// --- 2. Validation et Sécurisation des champs ---
$errors = [];

// Champs attendus
$name    = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
$email   = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING);
$message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

// Validation
if (empty($name) || strlen($name) < 2) {
    $errors[] = 'Le nom est requis et doit contenir au moins 2 caractères.';
}
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Une adresse e-mail valide est requise.';
}
if (empty($subject) || strlen($subject) < 5) {
    $errors[] = 'Le sujet est requis et doit contenir au moins 5 caractères.';
}
if (empty($message) || strlen($message) < 10) {
    $errors[] = 'Le message est requis et doit contenir au moins 10 caractères.';
}

if (!empty($errors)) {
    redirect('error', implode(' | ', $errors));
}

// --- 3. Construction et Envoi de l'e-mail ---

// En-têtes de l'e-mail
$headers = "From: " . $name . " <" . $email . ">\r\n";
$headers .= "Reply-To: " . $email . "\r\n";
$headers .= "CC: " . RECIPIENT_CC . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

// Corps de l'e-mail
$email_content = "Nouveau message de contact via le site web:\n\n";
$email_content .= "Nom: " . $name . "\n";
$email_content .= "Email: " . $email . "\n";
$email_content .= "Sujet: " . $subject . "\n";
$email_content .= "Message:\n" . $message . "\n\n";
$email_content .= "--- Informations techniques ---\n";
$email_content .= "IP de l'expéditeur: " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n";
$email_content .= "User Agent: " . ($_SERVER['HTTP_USER_AGENT'] ?? 'N/A') . "\n";

// Envoi de l'e-mail
$mail_sent = mail(RECIPIENT_TO, "SITE WEB: " . $subject, $email_content, $headers);

// --- 4. Affichage du message de succès ou d’erreur ---
if ($mail_sent) {
    redirect('success', 'Votre message a été envoyé avec succès. Nous vous répondrons dans les plus brefs délais.');
} else {
    // Erreur d'envoi (souvent due à une mauvaise configuration mail() sur l'hébergeur)
    redirect('error', 'Une erreur est survenue lors de l\'envoi de votre message. Veuillez réessayer plus tard ou nous contacter directement.');
}

// Fin du script
?>
