const translations = {
    "fr": {
        "about_title": "À PROPOS D'AMA-NEXUS INTERNATIONAL",
        "about_p1": "AMA-NEXUS International est un cabinet de conseil et d’accompagnement stratégique, spécialisé dans la sécurisation des investissements et la facilitation de projets complexes en Afrique de l'Ouest et au-delà. Notre mission est d'apporter une expertise opérationnelle, multi-pays et multi-secteurs à nos clients. **La Formation Professionnelle est un levier stratégique complémentaire à nos services de conseil, essentiel pour le renforcement des capacités institutionnelles et opérationnelles de nos clients.**",
        "about_p2": "Notre offre globale couvre la **Formation professionnelle**, le **Conseil stratégique et institutionnel**, la **Due diligence**, la facilitation des **Partenariats Public-Privé (PPP)**, les **Études de marché & implantation**, l'**Assistance pour l’obtention d’agréments et licences**, ainsi que l'accompagnement de **Projets immobiliers**.",
        "about_p3": "L'équipe est constituée de deux (2) structures partenaires, regroupant plusieurs **experts internationaux** aux compétences complémentaires : **juridiques, financières, stratégiques, techniques et institutionnelles**. Cette synergie garantit une approche complète et une forte expérience opérationnelle pour la réussite de vos projets.",
        
        "services_title": "NOS SERVICES SPÉCIALISÉS",
        
        "service_1_title": "1. Due Diligence Commerciale",
        "service_1_desc": "Analyse approfondie des aspects commerciaux, financiers et opérationnels d'une opportunité d'investissement. **Ce que nos clients gagnent :** Des décisions d'investissement sécurisées, une réduction drastique des risques cachés et la garantie de la viabilité à long terme de leurs projets.",
        
        "service_2_title": "2. Facilitation des Partenariats Public-Privé (PPP)",
        "service_2_desc": "Accompagnement complet pour la mise en place de PPP complexes. **Ce que nos clients gagnent :** Une accélération des processus administratifs, une sécurisation juridique et contractuelle des montages, et la concrétisation rapide de projets d'envergure publique ou parapublique.",
        
        "service_3_title": "3. Études de Marché & Implantation",
        "service_3_desc": "Réalisation d'études sectorielles et de faisabilité précises. **Ce que nos clients gagnent :** Une feuille de route d'implantation claire, des risques de marché anticipés, et un positionnement concurrentiel optimisé pour une croissance rapide en Afrique de l'Ouest.",
        
        "service_4_title": "4. Assistance pour l’Obtention d’Agréments & Licences",
        "service_4_desc": "Assistance complète pour l'obtention d'agréments et licences. **Ce que nos clients gagnent :** Un gain de temps considérable, l'assurance d'une conformité réglementaire totale, et la mise en exploitation rapide de leurs activités sans blocage administratif.",
        
        "service_5_title": "5. Projets Immobiliers",
        "service_5_desc": "Structuration complète de projets immobiliers, incluant les études de faisabilité, la recherche de financements et la facilitation de PPP immobiliers. **Ce que nos clients gagnent :** La sécurisation de leurs investissements immobiliers, une optimisation des montages financiers et une gestion de projet fluide de la conception à la livraison.",
        
        "service_6_title": "6. Formation Professionnelle & Renforcement des Capacités",
        "service_6_desc": "Nous proposons des formations sur mesure (présentiel, distanciel, intra-organisation) pour les institutions et organisations. **Exemple de thème :** Gouvernance territoriale et protection juridique de l’enfance et de la jeunesse. **Ce que nos clients gagnent :** Une montée en compétence rapide, une conformité réglementaire assurée, et une expertise opérationnelle immédiatement applicable. (Sans mention de durée ou volume horaire).",
        "service_7_title": "7. Recouvrement de Créances Complexes et Sensibles",
        "service_7_desc": "Gestion discrète et efficace de dossiers de recouvrement multi-juridictionnels et à forts enjeux. **Ce que nos clients gagnent :** La résolution de litiges bloqués, la récupération de flux financiers vitaux, et la protection de leur réputation grâce à une approche confidentielle et professionnelle.",
        
        "contact_title": "Contactez-Nous",
        "contact_name": "Votre Nom Complet",
        "contact_email": "Votre Adresse E-mail",
        "contact_subject": "Sujet de votre message",
        "contact_message": "Votre Message",
        "contact_button": "Envoyer le Message",
        
        // Formations existantes (pour la traduction)
        "form_1_title": "Droit Humanitaire International",
        "form_1_desc": "Maîtrisez les principes fondamentaux du droit humanitaire, les conventions de Genève et les obligations légales en matière de protection des personnes. **Bénéfice :** Renforcement immédiat de la conformité éthique et légale de vos équipes sur le terrain.",
        "form_1_mod1": "Conventions de Genève",
        "form_1_mod2": "Droit des conflits",
        "form_1_mod3": "Protection civile",
        "form_1_mod4": "Responsabilité légale",
        
        "form_2_title": "Gouvernance & Administration",
        "form_2_desc": "Apprenez les meilleures pratiques en gouvernance d'entreprise, gestion administrative et conformité réglementaire pour une organisation efficace. **Bénéfice :** Amélioration de la transparence, réduction des risques de corruption et optimisation de la performance institutionnelle.",
        "form_2_mod1": "Gouvernance d'entreprise",
        "form_2_mod2": "Gestion administrative",
        "form_2_mod3": "Conformité légale",
        "form_2_mod4": "Audit interne",
        
        "form_3_title": "Entrepreneuriat des Jeunes",
        "form_3_desc": "Lancez votre entreprise avec confiance ! Formation complète sur la création d'entreprise, le business plan et la gestion financière pour jeunes entrepreneurs. **Bénéfice :** Acquisition rapide des outils stratégiques pour une création d'entreprise pérenne et financée.",
        "form_3_mod1": "Création d'entreprise",
        "form_3_mod2": "Business plan",
        "form_3_mod3": "Financement startup",
        "form_3_mod4": "Marketing digital",
        
        "form_4_title": "Protection des Données & Sécurité",
        "form_4_desc": "Protégez votre organisation ! Maîtrisez les réglementations RGPD, la cybersécurité et les meilleures pratiques de protection des données. **Bénéfice :** Sécurisation de vos actifs numériques et mise en conformité immédiate avec les normes internationales.",
        "form_4_mod1": "RGPD & conformité",
        "form_4_mod2": "Cybersécurité",
        "form_4_mod3": "Gestion des risques",
        "form_4_mod4": "Audit de sécurité",
        
        "form_5_title": "Gestion Financière Avancée",
        "form_5_desc": "Maîtrisez les outils financiers modernes, l'analyse de trésorerie et la planification financière stratégique pour optimiser vos ressources. **Bénéfice :** Meilleure visibilité financière, optimisation des flux de trésorerie et décisions d'investissement plus rentables.",
        "form_5_mod1": "Analyse financière",
        "form_5_mod2": "Gestion de trésorerie",
        "form_5_mod3": "Planification budgétaire",
        "form_5_mod4": "Investissement stratégique",
        
        "form_6_title": "Leadership & Management Stratégique",
        "form_6_desc": "Développez vos compétences de leader ! Formation sur le management d'équipe, la prise de décision stratégique et le développement organisationnel. **Bénéfice :** Équipes plus performantes, gestion de crise facilitée et vision stratégique alignée sur les objectifs de l'organisation.",
        "form_6_mod1": "Leadership transformationnel",
        "form_6_mod2": "Gestion d'équipe",
        "form_6_mod3": "Stratégie d'entreprise",
        "form_6_mod4": "Gestion du changement",
        
        "form_button": "En Savoir Plus",
        "form_modules_label": "Modules :",
        "form_section_title": "Nos Programmes de Formation",
        "form_section_subtitle": "Développez vos compétences avec nos formations spécialisées en droit humanitaire, gouvernance, entrepreneuriat et protection",
        
        // Nouveau service (Formations spécialisées & Due Diligence)
        "form_7_title": "Formations spécialisées & Due Diligence",
        "form_7_desc": "Expertise pointue en droit des enfants, formations sur mesure et évaluation stratégique des risques pour sécuriser vos décisions. **Bénéfice :** Sécurisation juridique de vos projets sensibles et alignement de votre gouvernance sur les meilleures pratiques internationales.",
        "form_7_sub1_title": "Formations spécialisées",
        "form_7_sub1_label": "Thèmes principaux",
        "form_7_mod1": "Droit des Enfants",
        "form_7_mod2": "Protection des droits de l’enfant",
        "form_7_mod3": "Cadres juridiques nationaux et internationaux",
        "form_7_mod4": "Prévention et conformité institutionnelle",
        "form_7_mod5": "Formations sur mesure (Institutions, ONG, Entreprises)",
        "form_7_mod6": "Renforcement des capacités opérationnelles",
        "form_7_sub2_title": "Due Diligence Stratégique",
        "form_7_sub2_label": "Domaines d'intervention",
        "form_7_mod7": "Due diligence commerciale, financière et opérationnelle",
        "form_7_mod8": "Analyse des risques et opportunités",
        "form_7_mod9": "Évaluation de projets et partenaires",
        "form_7_mod10": "Sécurisation des décisions d’investissement",
        "form_7_button": "Contactez-nous pour ce service",

        // Ajouts du 22/12/2025
        "form_8_title": "GOUVERNANCE TERRITORIALE ET PROTECTION JURIDIQUE DE L'ENFANCE",
        "form_8_desc": "Un exemple de nos thèmes de formation. Plusieurs autres sont disponibles sur demande. Contactez AMA NEXUS International pour obtenir le catalogue complet et discuter de formations sur-mesure.",
        "experts_title": "UNE ÉQUIPE D'EXPERTS À VOTRE SERVICE",
        "experts_desc": "L'équipe d'AMA NEXUS International est composée d'experts et de consultants de haut niveau issus de grandes institutions internationales, avec plus de 30 ans d'expérience cumulée. Nos domaines d'expertise incluent l'observation internationale d'élections, le recouvrement complexe de créances, les Partenariats Public-Privé (PPP), le commerce international, l'entrepreneuriat, le conseil en investissement, la facilitation financière, et bien d'autres. Nous ciblons entre autres l'administration publique, les projets de développement et humanitaires. **Nous garantissons un respect strict de la confidentialité dans toutes nos interventions.**"
    },
    "en": {
        "about_title": "ABOUT AMA-NEXUS INTERNATIONAL",
        "about_p1": "AMA-NEXUS International is a consulting, training, and strategic support firm, specializing in securing investments and facilitating complex projects in West Africa and beyond. Our mission is to bring operational, multi-country, and multi-sector expertise to our clients.",
        "about_p2": "Our comprehensive offering covers **Strategic and Institutional Consulting**, **Professional Training**, **Due Diligence**, facilitation of **Public-Private Partnerships (PPP)**, **Market Studies & Implementation**, **Assistance for obtaining approvals and licenses**, as well as support for **Real Estate Projects**.",
        "about_p3": "The team consists of two (2) partner structures, bringing together several **international experts** with complementary skills: **legal, financial, strategic, technical, and institutional**. This synergy guarantees a complete approach and strong operational experience for the success of your projects.",
        
        "services_title": "OUR SPECIALIZED SERVICES",
        
        "service_1_title": "1. Commercial Due Diligence",
        "service_1_desc": "In-depth analysis of the commercial, financial, and operational aspects of an investment opportunity. **What our clients gain:** Secured investment decisions, a drastic reduction in hidden risks, and the guarantee of long-term project viability.",
        
        "service_2_title": "2. Public-Private Partnership (PPP) Facilitation",
        "service_2_desc": "Comprehensive support for setting up complex PPPs. **What our clients gain:** Accelerated administrative processes, legal and contractual security for project structures, and the rapid realization of large-scale public or parapublic projects.",
        
        "service_3_title": "3. Market Studies & Implementation",
        "service_3_desc": "Conducting precise sectoral and feasibility studies. **What our clients gain:** A clear implementation roadmap, anticipated market risks, and optimized competitive positioning for rapid growth in West Africa.",
        
        "service_4_title": "4. Assistance for Obtaining Approvals & Licenses",
        "service_4_desc": "Comprehensive assistance for obtaining approvals and licenses. **What our clients gain:** Significant time savings, assurance of total regulatory compliance, and rapid operationalization of their activities without administrative blockage.",
        
        "service_5_title": "5. Real Estate Projects",
        "service_5_desc": "Complete structuring of real estate projects, including feasibility studies, financing search, and facilitation of real estate PPPs. **What our clients gain:** The security of their real estate investments, optimized financial structures, and fluid project management from conception to delivery.",
        
        "service_6_title": "6. Professional Training & Capacity Building",
        "service_6_desc": "We offer tailor-made training (in-person, distance, in-house) for institutions and organizations. **Example theme:** Territorial Governance and Legal Protection of Childhood and Youth. **What our clients gain:** Rapid skill enhancement, ensured regulatory compliance, and immediately applicable operational expertise. (Without mentioning duration or hourly volume).",
        "service_7_title": "7. Complex and Sensitive Debt Recovery",
        "service_7_desc": "Discreet and effective management of multi-jurisdictional and high-stakes recovery cases. **What our clients gain:** Resolution of blocked disputes, recovery of vital financial flows, and protection of their reputation through a confidential and professional approach.",
        
        "contact_title": "Contact Us",
        "contact_name": "Your Full Name",
        "contact_email": "Your Email Address",
        "contact_subject": "Subject of your message",
        "contact_message": "Your Message",
        "contact_button": "Send Message",
        
        // Existing Training (for translation)
        "form_1_title": "International Humanitarian Law",
        "form_1_desc": "Master the fundamental principles of humanitarian law, the Geneva Conventions, and legal obligations regarding the protection of individuals. **Benefit:** Immediate strengthening of the ethical and legal compliance of your field teams.",
        "form_1_mod1": "Geneva Conventions",
        "form_1_mod2": "Law of conflicts",
        "form_1_mod3": "Civil protection",
        "form_1_mod4": "Legal responsibility",
        
        "form_2_title": "Governance & Administration",
        "form_2_desc": "Learn best practices in corporate governance, administrative management, and regulatory compliance for an efficient organization. **Benefit:** Improved transparency, reduced corruption risks, and optimized institutional performance.",
        "form_2_mod1": "Corporate governance",
        "form_2_mod2": "Administrative management",
        "form_2_mod3": "Legal compliance",
        "form_2_mod4": "Internal audit",
        
        "form_3_title": "Youth Entrepreneurship",
        "form_3_desc": "Launch your business with confidence! Comprehensive training on business creation, business planning, and financial management for young entrepreneurs. **Benefit:** Rapid acquisition of strategic tools for sustainable and funded business creation.",
        "form_3_mod1": "Business creation",
        "form_3_mod2": "Business plan",
        "form_3_mod3": "Startup financing",
        "form_3_mod4": "Digital marketing",
        
        "form_4_title": "Data Protection & Security",
        "form_4_desc": "Protect your organization! Master GDPR regulations, cybersecurity, and best practices for data protection. **Benefit:** Securing your digital assets and immediate compliance with international standards.",
        "form_4_mod1": "GDPR & compliance",
        "form_4_mod2": "Cybersecurity",
        "form_4_mod3": "Risk management",
        "form_4_mod4": "Security audit",
        
        "form_5_title": "Advanced Financial Management",
        "form_5_desc": "Master modern financial tools, cash flow analysis, and strategic financial planning to optimize your resources. **Benefit:** Better financial visibility, optimized cash flows, and more profitable investment decisions.",
        "form_5_mod1": "Financial analysis",
        "form_5_mod2": "Cash management",
        "form_5_mod3": "Budget planning",
        "form_5_mod4": "Strategic investment",
        
        "form_6_title": "Strategic Leadership & Management",
        "form_6_desc": "Develop your leadership skills! Training on team management, strategic decision-making, and organizational development. **Benefit:** More efficient teams, facilitated crisis management, and strategic vision aligned with organizational goals.",
        "form_6_mod1": "Transformational leadership",
        "form_6_mod2": "Team management",
        "form_6_mod3": "Business strategy",
        "form_6_mod4": "Change management",
        
        "form_button": "Learn More",
        "form_modules_label": "Modules:",
        "form_section_title": "Our Training Programs",
        "form_section_subtitle": "Develop your skills with our specialized training in humanitarian law, governance, entrepreneurship, and protection",
        
        // New service (Specialized Training & Due Diligence)
        "form_7_title": "Specialized Training & Due Diligence",
        "form_7_desc": "Advanced expertise in children's rights, tailor-made training, and strategic risk assessment to secure your decisions. **Benefit:** Legal security for your sensitive projects and alignment of your governance with international best practices.",
        "form_7_sub1_title": "Specialized Training",
        "form_7_sub1_label": "Main Themes",
        "form_7_mod1": "Children's Rights",
        "form_7_mod2": "Protection of children's rights",
        "form_7_mod3": "National and international legal frameworks",
        "form_7_mod4": "Prevention and institutional compliance",
        "form_7_mod5": "Tailor-made training (Institutions, NGOs, Companies)",
        "form_7_mod6": "Operational capacity building",
        "form_7_sub2_title": "Strategic Due Diligence",
        "form_7_sub2_label": "Areas of Intervention",
        "form_7_mod7": "Commercial, financial, and operational due diligence",
        "form_7_mod8": "Risk and opportunity analysis",
        "form_7_mod9": "Project and partner evaluation",
        "form_7_mod10": "Securing investment decisions",
        "form_7_button": "Contact us for this service",

        // Additions from 2025-12-22
        "form_8_title": "TERRITORIAL GOVERNANCE AND LEGAL PROTECTION OF CHILDHOOD",
        "form_8_desc": "An example of our training themes. Several others are available on request. Contact AMA NEXUS International to get the full catalog and discuss tailor-made training.",
        "experts_title": "A TEAM OF EXPERTS AT YOUR SERVICE",
        "experts_desc": "The AMA NEXUS International team is composed of high-level experts and consultants from major international institutions, with over 30 years of cumulative experience. Our areas of expertise include international election observation, complex debt recovery, Public-Private Partnerships (PPPs), international trade, entrepreneurship, investment consulting, financial facilitation, and many others. Our targets include public administration, development and humanitarian projects. **We guarantee strict confidentiality in all our interventions.**"
    }
};

let currentLang = 'fr'; // Default to French

function setLanguage(lang) {
    // Fonction désactivée pour garantir le 100% français
    // currentLang = lang;
    // localStorage.setItem('lang', lang);
    // applyTranslations();
}

function applyTranslations() {
    const langData = translations[currentLang];
    
    // Translate elements with data-translate attribute
    document.querySelectorAll('[data-translate]').forEach(element => {
        const key = element.getAttribute('data-translate');
        if (langData[key]) {
            element.innerHTML = langData[key];
        }
    });

    // Translate placeholders
    document.querySelectorAll('[data-translate-placeholder]').forEach(element => {
        const key = element.getAttribute('data-translate-placeholder');
        if (langData[key]) {
            element.placeholder = langData[key];
        }
    });
    
    // Update lang attribute of <html> tag
    document.documentElement.setAttribute('lang', currentLang);
}

// Initialization
document.addEventListener('DOMContentLoaded', () => {
    // Suppression de la logique de basculement linguistique pour forcer le français
    // const storedLang = localStorage.getItem('lang');
    // if (storedLang) {
    //     currentLang = storedLang;
    // }
    applyTranslations();
});
